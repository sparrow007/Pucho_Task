package com.jackandphantom.stackquestion.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.jackandphantom.stackquestion.R;
import com.jackandphantom.stackquestion.model.QuestionData;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class QuestionListAdapter extends RecyclerView.Adapter<QuestionListAdapter.ViewHolder> {

    private List<QuestionData> questionData;
    private LayoutInflater layoutInflater;

    public QuestionListAdapter(List<QuestionData> questionData, Context context) {
        this.questionData = questionData;
        layoutInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.question_list_layout,null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        QuestionData data = questionData.get(position);
        holder.questionTitle.setText(data.getTitle());
        holder.questionDes.setText(data.getBody());
        holder.circleImageView.setTag(data.getOwnerData().getProfile_image());
        holder.userName.setText(data.getOwnerData().getDisplay_name());
        holder.postTime.setText(String.valueOf(data.getCreation_date()));
    }

    @Override
    public int getItemCount() {
        return questionData.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        CircleImageView circleImageView;
        TextView questionTitle, questionDes, userName, postTime;
         ViewHolder(@NonNull View itemView) {
            super(itemView);
            circleImageView = itemView.findViewById(R.id.user_profile);
            questionTitle = itemView.findViewById(R.id.question_title);
             questionDes = itemView.findViewById(R.id.question_body);
             userName = itemView.findViewById(R.id.user_name);
             postTime = itemView.findViewById(R.id.time);

        }
    }

}
