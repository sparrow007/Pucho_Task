package com.jackandphantom.stackquestion.UI;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.jackandphantom.stackquestion.R;
import com.jackandphantom.stackquestion.Utils.SharedPreferenceUtil;

import java.net.URI;
import java.net.URISyntaxException;

import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    private Button textView;
    private  WebView webView;
    private ProgressDialog dialog;
    private SharedPreferenceUtil sharedPreferenceUtil;
    private RelativeLayout relativeLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        sharedPreferenceUtil = new SharedPreferenceUtil(MainActivity.this);
        if (sharedPreferenceUtil.getFirstTimeLogin()) {

        }
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.login);
        relativeLayout = findViewById(R.id.layout);
        webView = findViewById(R.id.web);

        final Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://stackoverflow.com/")
                .build();

//Log.e("MY TAG", "STRING "+response.raw());
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog = ProgressDialog.show(MainActivity.this, "Loading", "Please wait...", true);

                webView.getSettings().setLoadsImagesAutomatically(true);
                webView.getSettings().setJavaScriptEnabled(true);
                webView.setVisibility(View.VISIBLE);
                webView.setWebViewClient(new WebViewClient(MainActivity.this));
                webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                webView.loadUrl("https://stackoverflow.com/oauth/dialog?client_id=14798" +
                        "&redirect_uri=https://com.jackandphantom.stackquestion&scope=no_expiry");

             /*retrofit.create(StackApi.class).stackAuthCall(14798,
                     "https://com.jackandphantom.stackquestion").enqueue(new Callback<ResponseBody>() {
                 @Override
                 public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                     Log.e("MY TAG", "STRING "+response.raw());
                 }

                 @Override
                 public void onFailure(Call<ResponseBody> call, Throwable t) {
                     t.printStackTrace();
                 }
             }); */

            }
        });
    }

    public class WebViewClient extends android.webkit.WebViewClient
    {
        private boolean loadingFinished = true;
        private boolean redirect = false;

         WebViewClient(Context context) {

        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {

            // TODO Auto-generated method stub

            Log.e("MY TAG", "URL in start "+url);
            loadingFinished = false;
            try {
                String hash = new URI(url).getFragment();
                int index = hash.indexOf("=");
                String sub = hash.substring(index+1);
                sharedPreferenceUtil.setAcessToken(sub);
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }catch (NullPointerException e) {
                e.printStackTrace();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            // TODO Auto-generated method stub
            if (!loadingFinished) {
                redirect = true;
            }

            loadingFinished = false;
            view.loadUrl(url);
            return true;
        }
        @Override
        public void onPageFinished(WebView view, String url) {

            // TODO Auto-generated method stub
            if(!redirect){
                loadingFinished = true;
            }

            if(loadingFinished && !redirect){
                //HIDE LOADING IT HAS FINISHED
                if(dialog.isShowing())
                   dialog.dismiss();
                relativeLayout.setVisibility(View.GONE);

            } else{
                redirect = false;
            }



        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            Log.e("MY TAG", "PAGE NOT FOUND");
            sharedPreferenceUtil.setFirstTimeLogin(true);
            view.setVisibility(View.GONE);
        }
    }
}
